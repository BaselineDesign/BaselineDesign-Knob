#pragma once

#define I2C_MASTER
#define I2C1_SDA_PIN GP2
#define I2C1_SCL_PIN GP3
#define I2C_MASTER_ENABLE
#define BOOTMAGIC_ROW 0
#define BOOTMAGIC_COLUMN 0

